const https = require('https');

exports.handler = async (event, context) => {
  // CORS Headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method Not Allowed' }) };
  }

  try {
    const { orderId, amount, customerPhone, customerEmail, customerName } = JSON.parse(event.body);

    // Cashfree PG Sandbox Credentials
    const appId = "1074441c07d59995d4a2137115a1444701";
    const secretKey = "cfsk_ma_prod_57ab062d72f21815885e04fe6cc4aedd_95d7e257";

    const postData = JSON.stringify({
      order_id: orderId,
      order_amount: parseFloat(amount),
      order_currency: "INR",
      customer_details: {
        customer_id: "cust_" + customerPhone.replace(/\s+/g, ''),
        customer_phone: customerPhone,
        customer_name: customerName || "Guest Customer",
        customer_email: customerEmail || "support@fmplanetstore.com"
      }
    });

    const options = {
      hostname: 'sandbox.cashfree.com', // Change to 'api.cashfree.com' for production
      port: 443,
      path: '/pg/orders',
      method: 'POST',
      headers: {
        'x-client-id': appId,
        'x-client-secret': secretKey,
        'x-api-version': '2023-08-01',
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData)
      }
    };

    return new Promise((resolve) => {
      const req = https.request(options, (res) => {
        let responseData = '';
        res.on('data', (chunk) => { responseData += chunk; });
        res.on('end', () => {
          try {
            const parsedData = JSON.parse(responseData);
            resolve({
              statusCode: res.statusCode,
              headers,
              body: JSON.stringify({
                payment_session_id: parsedData.payment_session_id,
                order_id: parsedData.order_id
              })
            });
          } catch (e) {
            resolve({ statusCode: 500, headers, body: JSON.stringify({ error: 'Failed parsing payment payload' }) });
          }
        });
      });

      req.on('error', (e) => {
        resolve({ statusCode: 500, headers, body: JSON.stringify({ error: e.message }) });
      });

      req.write(postData);
      req.end();
    });

  } catch (err) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: err.message }) };
  }
};