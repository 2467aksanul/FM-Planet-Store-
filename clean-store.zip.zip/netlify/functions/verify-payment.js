const https = require('https');

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod !== 'GET') {
    return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method Not Allowed' }) };
  }

  const { order_id } = event.queryStringParameters;
  if (!order_id) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Missing order_id parameter' }) };
  }

  // Cashfree PG Sandbox Credentials
  const appId = "1074441c07d59995d4a2137115a1444701";
  const secretKey = "cfsk_ma_prod_57ab062d72f21815885e04fe6cc4aedd_95d7e257";

  const options = {
    hostname: 'sandbox.cashfree.com', // Change to 'api.cashfree.com' for production
    port: 443,
    path: `/pg/orders/${order_id}`,
    method: 'GET',
    headers: {
      'x-client-id': appId,
      'x-client-secret': secretKey,
      'x-api-version': '2023-08-01'
    }
  };

  return new Promise((resolve) => {
    const req = https.request(options, (res) => {
      let responseData = '';
      res.on('data', (chunk) => { responseData += chunk; });
      res.on('end', () => {
        try {
          const parsedData = JSON.parse(responseData);
          if (parsedData.order_status === 'PAID') {
            resolve({
              statusCode: 200,
              headers,
              body: JSON.stringify({ status: "SUCCESS", details: parsedData })
            });
          } else {
            resolve({
              statusCode: 200,
              headers,
              body: JSON.stringify({ status: "FAILED", order_status: parsedData.order_status })
            });
          }
        } catch (e) {
          resolve({ statusCode: 500, headers, body: JSON.stringify({ error: 'Failed parsing verification payload' }) });
        }
      });
    });

    req.on('error', (e) => {
      resolve({ statusCode: 500, headers, body: JSON.stringify({ error: e.message }) });
    });

    req.end();
  });
};